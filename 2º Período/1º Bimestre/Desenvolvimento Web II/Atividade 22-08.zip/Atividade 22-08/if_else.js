const numero = prompt ("Digite um número diferente de zero: ")
    if (numero < 0){
        alert ("O número é negativo!")
    } else if (numero > 0){                
        alert ("O número é positivo!")
    } else {
        alert ("Numero inválido. Digite um valor diferente de zero!")
    } 