function mudarCor() {
    document.body.style.backgroundColor = "blue";
}

function voltarCor(){
    document.body.style.backgroundColor = "white";
}