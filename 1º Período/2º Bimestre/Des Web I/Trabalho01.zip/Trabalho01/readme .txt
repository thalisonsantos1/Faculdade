Inicialmente foi criada uma página principal onde a mesma traz informações iniciais sobre o conteúdo das demais páginas.

No cabeçalho, temos links para outras páginas onde as mesmas trazem as informações pertinentes ao conteúdo.
Todas as páginas, com excessão da HOME, tem um link onde o usuário consegue voltar para a home e/ou conferir as demais páginas.