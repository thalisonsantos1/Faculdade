function mudarCorParaAzul(){
    document.body.style.backgroundColor = "blue";
}